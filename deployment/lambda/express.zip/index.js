"use strict";
const serverless = require('serverless-http'); // AWS Lambda

const express = require('express');
const app = express();
const port = 3000;

const cors = require('cors');

const jwt = require('jsonwebtoken');
const jwksClient = require('jwks-rsa');

const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand, ScanCommand, QueryCommand, PutCommand } = require('@aws-sdk/lib-dynamodb');
const client = new DynamoDBClient({
    region: 'us-east-1',
    // endpoint: `http://localhost:${port}`,
});
const docClient = DynamoDBDocumentClient.from(client);

//jwt verify before proceeding
const JWTclient = jwksClient({
  jwksUri: 'https://cognito-idp.us-east-1.amazonaws.com/us-east-1_Rali2TdjH/.well-known/jwks.json' //change
});

function getKey(header, callback) {
  JWTclient.getSigningKey(header.kid, (err, key) => {
    const signingKey = key.getPublicKey();
    callback(null, signingKey);
  });
}

function verifyToken(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Token missing' });
  }

  jwt.verify(token, getKey, {
    audience: '1t1j0j6rumdc2qjdgfj4rostc9',
    issuer: 'https://cognito-idp.us-east-1.amazonaws.com/us-east-1_Rali2TdjH',
    algorithms: ['RS256']
  }, (err, decoded) => {
    if (err) {
      return res.status(401).json({ error: 'Token invalid' });
    }

    req.user = decoded;
    next();
  });
}

// Middleware to parse JSON bodies
app.use(express.json());
app.use(cors({origin: 'http://team06website.s3-website-us-east-1.amazonaws.com/'})); //change s3

app.use(verifyToken);

// Basic route
app.get('/scan', async (req, res) => {
    const command = new ScanCommand({
        TableName: 'team06-WasherStatus' //change
    });
    try {
        const data = await docClient.send(command);
        res.json({
            items: data.Items, 
            count: data.Count,
            scannedCount: data.ScannedCount
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
//   res.send('Hello from Express!');
});

app.get('/washer/:id', async (req, res) => {
    const command = new GetCommand({
        TableName: 'team06-WasherStatus', //change
        Key: { 
            washer_id: parseInt(req.params.id),
        },
    });
    try {
        const data = await docClient.send(command);
        if (data.Item) {
            res.json(data.Item || {});
        } else {
            res.status(404).json({ error: `Item with input "${req.params.input}" not found` });
        }
    } catch (error) {
        console.error('DynamoDB Error:', error);
        res.status(500).json({ error: error.message });
    }
//   res.send('Hello from Express!');
});

app.get('/latest/:boardId', async (req, res) => {
    const command = new QueryCommand({
        TableName: 'BusStopHistoryInfo', //change
        KeyConditionExpression: 'board_id = :boardId',
        ExpressionAttributeValues: { 
            ':boardId': parseInt(req.params.boardId),
        },
        ScanIndexForward: false, // Sort in descending order
        Limit: 1, // Limit to the latest item
    });
    try {
        const data = await docClient.send(command);
        if (data.Items && data.Items.length > 0) {
            res.json(data.Items[0]);
        } else {
            res.status(404).json({ error: `No items found for board_id ${req.params.boardId}` });
        }
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
//   res.send('Hello from Express!');
});

app.post('/item', async (req, res) => {
    const { user_id, email } = req.body;

  if (!user_id || !email) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const params = {
    TableName: 'team06-UserInfo',
    Item: {
      user_id: Number(user_id),        // Partition key
      email
    }
  };

  try {
    await docClient.send(new PutCommand(params));
    res.status(200).json({ message: 'Item added successfully' });
  } catch (err) {
    console.error('DynamoDB Error:', err);
    res.status(500).json({ error: 'Could not insert item' });
  }
});

// // Start the server
// app.listen(port, () => {
//   console.log(`Server running at http://localhost:${port}`);
// });

module.exports.handler = serverless(app); // AWS Lambda