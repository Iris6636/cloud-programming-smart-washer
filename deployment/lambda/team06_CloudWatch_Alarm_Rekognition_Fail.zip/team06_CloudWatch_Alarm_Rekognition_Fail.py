import json

def lambda_handler(event, context):
    print("CloudWatch Alarm - Rekognition Fail triggered")
    print(json.dumps(event))
    return {
        'statusCode': 200,
        'body': json.dumps('Alarm processed')
    }
